import os, re, shutil, glob

ANDROID = 'android'
MANIFEST = f'{ANDROID}/app/src/main/AndroidManifest.xml'
GRADLE = f'{ANDROID}/app/build.gradle'
version_code = os.environ.get('VERSION_CODE', '1')

# ---- AndroidManifest: izin lokasi, rotasi portrait/landscape, tanpa backup
m = open(MANIFEST, encoding='utf-8').read()
perms = [
    'android.permission.ACCESS_FINE_LOCATION',
    'android.permission.ACCESS_COARSE_LOCATION',
    'android.permission.WAKE_LOCK',
]
add = ''.join(f'    <uses-permission android:name="{p}" />\n' for p in perms if p not in m)
m = m.replace('<application', add + '    <application', 1) if add else m
m = re.sub(r'android:allowBackup="[^"]*"', 'android:allowBackup="false"', m)
if 'android:screenOrientation' not in m:
    m = m.replace('<activity', '<activity\n            android:screenOrientation="fullSensor"', 1)
open(MANIFEST, 'w', encoding='utf-8').write(m)

# ---- Versi: naik otomatis tiap build supaya APK baru bisa menimpa yang lama
g = open(GRADLE, encoding='utf-8').read()
g = re.sub(r'versionCode\s+\d+', f'versionCode {version_code}', g)
g = re.sub(r'versionName\s+"[^"]*"', f'versionName "1.0.{version_code}"', g)
open(GRADLE, 'w', encoding='utf-8').write(g)

# ---- MainActivity
dst = f'{ANDROID}/app/src/main/java/com/ayoso/hanana/MainActivity.java'
os.makedirs(os.path.dirname(dst), exist_ok=True)
shutil.copy('android-extra/MainActivity.java', dst)

# ---- Ikon aplikasi
res = f'{ANDROID}/app/src/main/res'
shutil.rmtree(f'{res}/mipmap-anydpi-v26', ignore_errors=True)
for d in ('mdpi', 'hdpi', 'xhdpi', 'xxhdpi', 'xxxhdpi'):
    folder = f'{res}/mipmap-{d}'
    os.makedirs(folder, exist_ok=True)
    for name in ('ic_launcher.png', 'ic_launcher_round.png', 'ic_launcher_foreground.png'):
        shutil.copy(f'android-extra/icons/ic_launcher-{d}.png', f'{folder}/{name}')

print('Patch selesai. versionCode =', version_code)
