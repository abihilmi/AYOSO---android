package com.ayoso.hanana;

import android.os.Bundle;
import android.view.WindowManager;
import android.webkit.WebSettings;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Layar tetap menyala agar jam & hitung mundur sholat selalu terlihat
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    @Override
    public void onStart() {
        super.onStart();
        try {
            WebSettings ws = getBridge().getWebView().getSettings();
            // Suara adzan/alarm boleh berbunyi otomatis tanpa harus disentuh dulu
            ws.setMediaPlaybackRequiresUserGesture(false);
            // Proteksi: tidak boleh membaca file lokal lain lewat WebView
            ws.setAllowFileAccessFromFileURLs(false);
            ws.setAllowUniversalAccessFromFileURLs(false);
        } catch (Exception ignored) {}
    }
}
