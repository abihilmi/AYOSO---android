AYOSO - Android Project (HANANA House)

CARA REVISI
1. Buka repo GitHub > folder "www" > file "index.html"
2. Klik ikon pensil / "Add file > Upload files", ganti dengan index.html baru
   (nama file harus tetap index.html), lalu Commit.
3. Tab "Actions" otomatis membuat APK baru (+- 5-8 menit).
4. Unduh APK di tab "Releases" (paling baru) atau di Actions > Artifacts.
5. Pasang di atas aplikasi lama - tidak perlu dihapus dulu, setting tetap ada.

ISI PROYEK
- www/index.html ............ aplikasi AYOSO (satu-satunya file yang diganti)
- capacitor.config.json ..... nama & ID aplikasi (com.ayoso.hanana)
- package.json .............. dependensi
- .github/workflows ......... resep otomatis pembuat APK
- android-extra/ ............ ikon, izin GPS, rotasi, layar menyala
- ayoso.keystore ............ kunci tanda tangan. JANGAN dihapus/diganti,
                              agar APK baru bisa menimpa APK lama.
